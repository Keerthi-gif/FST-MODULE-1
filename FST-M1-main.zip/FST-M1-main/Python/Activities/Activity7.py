
num = list(input("enter number: ").split(","))
sum = 0
for number in num:
    sum += int(number)
print(sum)
