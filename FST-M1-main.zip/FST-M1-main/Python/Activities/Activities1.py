name = input(("What is your name"))
print("Username is: "+ name)
age =int(input("Enter age:"))
print("Age is 2024 is : {}".format(age))


year = (2024 -age) + 100
print("{} truns 100 in the year {}".format( name, year))