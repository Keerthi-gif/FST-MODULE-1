num = int( input("enter number: ") )
Number=num % 2
if Number>0:
    print("Odd number:")
else:
    print("Even number:")